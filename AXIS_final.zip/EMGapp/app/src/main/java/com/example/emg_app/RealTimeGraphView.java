package com.example.emg_app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;
import java.util.ArrayList;

public class RealTimeGraphView extends View {
    private final int MAX_POINTS = 2000; // Câte puncte să vedem pe ecran odată
    private final ArrayList<Float> dataSensor1 = new ArrayList<>();
    private final ArrayList<Float> dataSensor2 = new ArrayList<>();

    private Paint paintGrid, paintLine1, paintLine2;
    private Path path1 = new Path();
    private Path path2 = new Path();

    public RealTimeGraphView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        paintGrid = new Paint();
        paintGrid.setColor(Color.parseColor("#222F4D")); // Liniile de grid: albastru discret
        paintGrid.setStrokeWidth(2f);

        paintLine1 = new Paint();
        paintLine1.setColor(Color.parseColor("#BB86FC")); // Linia 1: Mov Neon
        paintLine1.setStyle(Paint.Style.STROKE);
        paintLine1.setStrokeWidth(5f); // Am făcut-o o idee mai groasă să se vadă mișto
        paintLine1.setAntiAlias(true);

        paintLine2 = new Paint();
        paintLine2.setColor(Color.parseColor("#00B4D8")); // Linia 2: Albastru Electric Cyan
        paintLine2.setStyle(Paint.Style.STROKE);
        paintLine2.setStrokeWidth(5f);
        paintLine2.setAntiAlias(true);
    }

    public void addData(float val1, float val2) {
        // Presupunem că valorile MAV/RMS din ESP32 sunt între 0 și ~800
        dataSensor1.add(val1);
        dataSensor2.add(val2);

        if (dataSensor1.size() > MAX_POINTS) dataSensor1.remove(0);
        if (dataSensor2.size() > MAX_POINTS) dataSensor2.remove(0);

        invalidate(); // Cere reîmprospătarea graficului pe ecran
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth();
        int h = getHeight();

        // Desenare linii de fundal (Grid)
        for (int i = 1; i < 4; i++) {
            float y = (h / 4f) * i;
            canvas.drawLine(0, y, w, y, paintGrid);
        }

        if (dataSensor1.size() < 2) return;

        float stepX = (float) w / (MAX_POINTS - 1);
        float maxValue = 700f; // Scalează în funcție de pragul maxim observat la senzori

        path1.reset();
        path2.reset();

        for (int i = 0; i < dataSensor1.size(); i++) {
            float x = i * stepX;

            // Inversăm axa Y pentru că pe Android 0 este sus, iar valoarea maximă e jos
            float y1 = h - (dataSensor1.get(i) / maxValue) * h;
            float y2 = h - (dataSensor2.get(i) / maxValue) * h;

            // Constrângem valorile în interiorul ecranului
            if (y1 < 0) y1 = 0; if (y1 > h) y1 = h;
            if (y2 < 0) y2 = 0; if (y2 > h) y2 = h;

            if (i == 0) {
                path1.moveTo(x, y1);
                path2.moveTo(x, y2);
            } else {
                path1.lineTo(x, y1);
                path2.lineTo(x, y2);
            }
        }

        canvas.drawPath(path1, paintLine1);
        canvas.drawPath(path2, paintLine2);
    }
}