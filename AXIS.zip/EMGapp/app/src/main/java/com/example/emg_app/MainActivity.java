package com.example.emg_app;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    private final String NUME_DISPOZITIV_BT = "NeuroGrip_ESP32";
    private final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private Button btnConnect, btnStartCalib, btnStartSystem;
    private TextView txtStatus, txtGest, txtCalibTarget;
    private TextView tvMav1, tvRms1, tvMav2, tvRms2;
    private RealTimeGraphView realTimeGraph;
    private Button btnSkipCalib;
    private BluetoothAdapter bluetoothAdapter;
    private BluetoothSocket socket;
    private InputStream inputStream;
    private OutputStream outputStream;
    private boolean isConnected = false;
    private Thread workerThread;

        // Logica listei de calibrare
    private final String[] gesturi = {"ARATATOR", "MIJLOCIU", "INELAR", "REPAUS", "PUMN"};
    private int gestCurentIndex = 0;
    private boolean seColecteazaDateBrute = false;

    // Alocare statică eficientă pentru 1 minut de date (~1000Hz * 60s = 60000 eșantioane)
    // Alocăm 70000 pentru a preveni orice overflow în cazul în care transmisia variază ușor
    private final int MAX_SAMPLES_1MIN = 70000;
    private final int[] calibBufferS1 = new int[MAX_SAMPLES_1MIN];
    private final int[] calibBufferS2 = new int[MAX_SAMPLES_1MIN];
    private int sampleCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnConnect = findViewById(R.id.btnConnect);
        btnStartCalib = findViewById(R.id.btnStartCalib);
        btnStartSystem = findViewById(R.id.btnStartSystem);
        txtStatus = findViewById(R.id.txtStatus);
        txtGest = findViewById(R.id.txtGest);
        txtCalibTarget = findViewById(R.id.txtCalibTarget);

        tvMav1 = findViewById(R.id.tvMav1);
        tvRms1 = findViewById(R.id.tvRms1);
        tvMav2 = findViewById(R.id.tvMav2);
        tvRms2 = findViewById(R.id.tvRms2);
        realTimeGraph = findViewById(R.id.realTimeGraph);

        btnSkipCalib = findViewById(R.id.btnSkipCalib);

        btnSkipCalib.setOnClickListener(v -> {
            if (!isConnected) {
                Toast.makeText(this, "Conectează-te mai întâi!", Toast.LENGTH_SHORT).show();
                return;
            }
            // Cere ESP32 sa porneasca direct folosind centroizii din Flash
            trimiteComanda("CMD:START_RUN");
        });

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        btnConnect.setOnClickListener(v -> { if (!isConnected) verificaPermisiuniSiConecteaza(); });

        btnStartCalib.setOnClickListener(v -> {
            if (!isConnected) {
                Toast.makeText(this, "Conectează-te mai întâi la ESP32!", Toast.LENGTH_SHORT).show();
                return;
            }
            executaFereastraMasurare();
        });

        btnStartSystem.setOnClickListener(v -> trimiteComanda("CMD:START_RUN"));
    }

    private void executaFereastraMasurare() {
        sampleCount = 0; // Resetăm contorul pentru noul minut de măsurare
        seColecteazaDateBrute = true;

        btnStartCalib.setEnabled(false);
        txtCalibTarget.setText("MENȚINE GESTUL: " + gesturi[gestCurentIndex] + " (COLECTARE 1 MINUT)...");

        trimiteComanda("CMD:START_RAW");

        // Oprește eșantionarea brută după exact 60000 ms (1 minut)
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            trimiteComanda("CMD:STOP_RAW");
            seColecteazaDateBrute = false;
            calculeazaSiTrimiteCentroid();
        }, 60000);
    }

    private void calculeazaSiTrimiteCentroid() {
        if (sampleCount < 1000) { // Siguranță: dacă s-au pierdut pachete masiv pe Bluetooth
            Toast.makeText(this, "Eroare: Date insuficiente (" + sampleCount + " puncte). Reîncearcă!", Toast.LENGTH_SHORT).show();
            btnStartCalib.setEnabled(true);
            return;
        }

        // --- CALCUL MATEMATIC ULTRA-PRECIZ (PE O FERESTRĂ DE 1 MINUT) ---
        double sum1 = 0, sum2 = 0;
        double sqSum1 = 0, sqSum2 = 0;

        for (int i = 0; i < sampleCount; i++) {
            int val1 = calibBufferS1[i];
            int val2 = calibBufferS2[i];

            sum1 += val1;
            sum2 += val2;
            sqSum1 += (double) val1 * val1;
            sqSum2 += (double) val2 * val2;
        }

        float mav1 = (float) (sum1 / sampleCount);
        float mav2 = (float) (sum2 / sampleCount);
        float rms1 = (float) Math.sqrt(sqSum1 / sampleCount);
        float rms2 = (float) Math.sqrt(sqSum2 / sampleCount);

        // Transmitem structura centroidului înapoi pe ESP32
        String comandaCentroid = String.format("CENTROID:%d,%.2f,%.2f,%.2f,%.2f", gestCurentIndex, mav1, rms1, mav2, rms2);
        trimiteComanda(comandaCentroid);

        gestCurentIndex++;

        if (gestCurentIndex < gesturi.length) {
            txtCalibTarget.setText("PAS URMĂTOR: Pregătește " + gesturi[gestCurentIndex]);
            btnStartCalib.setEnabled(true);
        } else {
            txtCalibTarget.setText("CALIBRARE COMPLETĂ! Toate profilele de 1 min sunt salvate pe ESP32.");
            btnStartCalib.setVisibility(View.GONE);
            btnStartSystem.setVisibility(View.VISIBLE);
        }
    }

    private void trimiteComanda(String cmd) {
        if (outputStream != null && isConnected) {
            try {
                outputStream.write((cmd + "\n").getBytes());
                outputStream.flush();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void verificaPermisiuniSiConecteaza() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.BLUETOOTH_CONNECT}, 1);
            return;
        }

        BluetoothDevice espDevice = null;
        Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
        for (BluetoothDevice device : pairedDevices) {
            if (device.getName().equals(NUME_DISPOZITIV_BT)) { espDevice = device; break; }
        }

        if (espDevice != null) connectToDevice(espDevice);
        else Toast.makeText(this, "Asociază mai întâi NeuroGrip_ESP32 în setări!", Toast.LENGTH_LONG).show();
    }

    private void connectToDevice(BluetoothDevice device) {
        new Thread(() -> {
            try {
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) return;
                socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
                socket.connect();
                inputStream = socket.getInputStream();
                outputStream = socket.getOutputStream();
                isConnected = true;

                runOnUiThread(() -> {
                    txtStatus.setText("Conectat");
                    txtStatus.setTextColor(android.graphics.Color.GREEN);
                    btnConnect.setText("CONECTAT");
                });
                incepeAscultareDate();
            } catch (IOException e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Conexiunea a eșuat!", Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    private void incepeAscultareDate() {
        workerThread = new Thread(() -> {
            byte[] buffer = new byte[2048];
            StringBuilder stringBuilder = new StringBuilder();

            while (!Thread.currentThread().isInterrupted() && isConnected) {
                try {
                    int bytes = inputStream.read(buffer);
                    if (bytes > 0) {
                        stringBuilder.append(new String(buffer, 0, bytes));
                        int indexNouaLinie;

                        while ((indexNouaLinie = stringBuilder.indexOf("\n")) >= 0) {
                            String linieCompleta = stringBuilder.substring(0, indexNouaLinie).trim();
                            stringBuilder.delete(0, indexNouaLinie + 1);

                            // COLECTARE DATE BRUTE IN TIMPUL MINUTULUI DE CALIBRARE
                            if (seColecteazaDateBrute && linieCompleta.startsWith("RAW:")) {
                                String[] parti = linieCompleta.replace("RAW:", "").split(",");
                                if (parti.length == 2) {
                                    try {
                                        int valS1 = Integer.parseInt(parti[0]);
                                        int valS2 = Integer.parseInt(parti[1]);

                                        // Protecție la index out of bounds în vectori primitivi
                                        if (sampleCount < MAX_SAMPLES_1MIN) {
                                            calibBufferS1[sampleCount] = valS1;
                                            calibBufferS2[sampleCount] = valS2;
                                            sampleCount++;
                                        }

                                        // Feedback vizual instant pe grafic
                                        runOnUiThread(() -> realTimeGraph.addData(valS1, valS2));
                                    } catch (NumberFormatException e) {}
                                }
                            }
                            // MOD DE RULARE NORMAL (DECIDERE ACTIVĂ)
                            else if (linieCompleta.startsWith("GEST:")) {
                                String g = linieCompleta.replace("GEST:", "").trim();
                                runOnUiThread(() -> txtGest.setText(g));
                            }
                            // MONITORIZARE TELEMETRIE CURENTĂ (MAV/RMS)
                            else if (linieCompleta.startsWith("DATA:")) {
                                String[] valori = linieCompleta.replace("DATA:", "").split(",");
                                if (valori.length == 4) {
                                    runOnUiThread(() -> {
                                        tvMav1.setText("MAV: " + valori[0]); tvRms1.setText("RMS: " + valori[1]);
                                        tvMav2.setText("MAV: " + valori[2]); tvRms2.setText("RMS: " + valori[3]);

                                        if(!seColecteazaDateBrute) {
                                            realTimeGraph.addData(Float.parseFloat(valori[1]), Float.parseFloat(valori[3]));
                                        }
                                    });
                                }
                            }
                            else if (linieCompleta.startsWith("STATUS_RUN:OK")) {
                                runOnUiThread(() -> {
                                    txtCalibTarget.setText("Sistemul rulează cu centroizii stocați anterior.");
                                    btnStartCalib.setVisibility(View.GONE);
                                    btnSkipCalib.setVisibility(View.GONE);
                                    btnStartSystem.setVisibility(View.GONE);
                                    txtGest.setText("RULARE");
                                });
                            }
                            else if (linieCompleta.startsWith("ERR:")) {
                                runOnUiThread(() -> {
                                    Toast.makeText(MainActivity.this, "Eroare: Flash gol! Trebuie să calibrezi acum.", Toast.LENGTH_LONG).show();
                                });
                            }
                        }
                    }
                } catch (IOException e) {
                    isConnected = false;
                    runOnUiThread(() -> {
                        txtStatus.setText("Deconectat");
                        txtStatus.setTextColor(android.graphics.Color.RED);
                    });
                    break;
                }
            }
        });
        workerThread.start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        isConnected = false;
        try { if (socket != null) socket.close(); } catch (IOException e) {}
    }
}